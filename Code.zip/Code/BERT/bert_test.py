## sentence bert testing
import numpy as np
from sentence_transformers import SentenceTransformer
sbert_model = SentenceTransformer('bert-base-nli-mean-tokens')

inp_sent = ["How do I read and find my YouTube comments?"]

query = "How do I read and find my YouTube comments?"

sentence_embeddings = sbert_model.encode(inp_sent)

def cosine(u, v):
    return np.dot(u, v) / (np.linalg.norm(u) * np.linalg.norm(v))

query_vec = sbert_model.encode([query])[0]

for sent in inp_sent:
  sim = cosine(query_vec, sbert_model.encode([sent])[0])
  print("Sentence = ", sent, "; similarity = ", sim)


