# loading the model
import tensorflow as tf
import tensorflow_hub as hub
import numpy as np
import pandas as pd
import nltk 
from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize, sent_tokenize

module_url = "https://tfhub.dev/google/universal-sentence-encoder/4" 
model = hub.load(module_url)
print ("module %s loaded" % module_url)


# input and std data summarization

std_data = open("D:/Studies/Course Material/NLP Project/LSTM/mcl.txt","r",encoding='utf-8')
std_data = std_data.read()

inp_data = open("D:/Studies/Course Material/NLP Project/LSTM/mcl_opp.txt","r",encoding='utf-8')
inp_data = inp_data.read()

def summary(text):
  
    # Tokenizing the text 
    stopWords = set(stopwords.words("english")) 
    words = word_tokenize(text) 
       
    # Creating a frequency table to keep the  
    # score of each word 
       
    freqTable = dict() 
    for word in words: 
        word = word.lower() 
        if word in stopWords: 
            continue
        if word in freqTable: 
            freqTable[word] += 1
        else: 
            freqTable[word] = 1
       
    # Creating a dictionary to keep the score 
    # of each sentence 
    sentences = sent_tokenize(text) 
    sentenceValue = dict() 
       
    for sentence in sentences: 
        for word, freq in freqTable.items(): 
            if word in sentence.lower(): 
                if sentence in sentenceValue: 
                    sentenceValue[sentence] += freq 
                else: 
                    sentenceValue[sentence] = freq 
       
    sumValues = 0
    for sentence in sentenceValue: 
        sumValues += sentenceValue[sentence] 
       
    # Average value of a sentence from the original text 
       
    average = int(sumValues / len(sentenceValue)) 
       
    # Storing sentences into our summary. 
    summary = '' 
    for sentence in sentences: 
        if (sentence in sentenceValue) and (sentenceValue[sentence] > (1.2 * average)): 
            summary += " " + sentence 
    return summary
    
std_text_summary = [(summary(std_data))]
inp_text_summary = [(summary(inp_data))]

def cosine(u, v):
    return np.dot(u, v) / (np.linalg.norm(u) * np.linalg.norm(v))

sentence_embeddings = model(inp_text_summary)
  
query_vec = model(std_text_summary)

for sent in inp_text_summary:
  sim = cosine(query_vec, model([sent])[0])
  print("Sentence = ", sent, "; similarity = ", sim)


