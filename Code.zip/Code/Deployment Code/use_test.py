# universal sentence encoding test
import tensorflow as tf
import tensorflow_hub as hub
import numpy as np

module_url = "https://tfhub.dev/google/universal-sentence-encoder/4" 
model = hub.load(module_url)
print ("module %s loaded" % module_url)

std_sent = ['''McLaren have become the first F1 team to unveil their 2021 car, whipping the covers of the McLaren MCL35M that will be piloted by the squad’s new driver pairing of Daniel Ricciardo and Lando Norris this season.
''']

query = ['''McLaren have become the first F1 team to unveil their 2021 car, whipping the covers of the McLaren MCL35M that will be piloted by the squad’s new driver pairing of Daniel Ricciardo and Lando Norris this season.
''']

def cosine(u, v):
    return np.dot(u, v) / (np.linalg.norm(u) * np.linalg.norm(v))

sentence_embeddings = model(std_sent)
  
query_vec = model(query)

for sent in std_sent:
  print(sent)
  sim = cosine(query_vec, model([sent])[0])
  print("Sentence = ", sent, "; similarity = ", sim)

