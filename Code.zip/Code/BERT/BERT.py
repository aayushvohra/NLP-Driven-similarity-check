import numpy as np
from sentence_transformers import SentenceTransformer
sbert_model = SentenceTransformer('bert-base-nli-mean-tokens')

std_data = open("D:/Studies/Course Material/NLP Project/LSTM/mcl.txt","r")
std_data = std_data.read()

std_doc=[std_data]

inp_data = open("D:/Studies/Course Material/NLP Project/LSTM/mcl_opp.txt","r")
inp_data = inp_data.read()

inp_doc=[inp_data]

sentence_embeddings = sbert_model.encode(std_doc)

def cosine(u, v):
    return np.dot(u, v) / (np.linalg.norm(u) * np.linalg.norm(v))

query_vec = sbert_model.encode(inp_doc)

for sent in std_doc:
  sim = cosine(query_vec, sbert_model.encode(sent))
  print("Similarity = ", sim)


