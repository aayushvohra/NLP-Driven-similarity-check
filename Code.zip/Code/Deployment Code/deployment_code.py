from io import BytesIO

from flask import Flask, render_template, request, redirect, url_for,abort,send_from_directory
from nltk.sentiment import SentimentIntensityAnalyzer
from werkzeug.utils import secure_filename    #helps us to convert bad filename into secure filename
import os
import tensorflow as tf
import tensorflow_hub as hub
import numpy as np
import pandas as pd
import nltk 
from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize, sent_tokenize

module_url = "https://tfhub.dev/google/universal-sentence-encoder/4" 
model = hub.load(module_url)

def cosine(u, v):
    return np.dot(u, v) / (np.linalg.norm(u) * np.linalg.norm(v))

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('simple.html')
@app.route('/predict',methods=['GET','POST'])
def predict():
    if request.method == 'POST':
        standard_input = request.form['standard']
        standard_input = [standard_input]
        query = request.form['query']
        query = [query]
        sentence_embeddings = model(standard_input)
        query_vec = model(query)
        for sent in standard_input:
            sim = cosine(query_vec, model([sent])[0])
            my_prediction = round(float(sim) * 100, 2)
    return render_template('result.html',prediction = my_prediction)

if __name__ == '__main__':
    app.run(debug=True,use_reloader=False)

